public class TV {
    // Atribut (Data)
    int channel = 1; // Channel default adalah 1
    int volumeLevel = 1; // Volume default adalah 1
    boolean on = false; // TV dalam keadaan mati secara default

    // Konstruktor kosong
    public TV() {
    }

    // Method untuk menyalakan TV
    public void turnOn() {
        on = true;
    }

    // Method untuk mematikan TV
    public void turnOff() {
        on = false;
    }

    // Method untuk mengatur channel baru
    public void setChannel(int newChannel) {
        if (on && newChannel >= 1 && newChannel <= 120) {
            channel = newChannel;
        }
    }

    // Method untuk mengatur volume baru
    public void setVolume(int newVolumeLevel) {
        if (on && newVolumeLevel >= 1 && newVolumeLevel <= 7) {
            volumeLevel = newVolumeLevel;
        }
    }

    // Method untuk menaikkan channel
    public void channelUp() {
        if (on && channel < 120) {
            channel++;
        }
    }

    // Method untuk menurunkan channel
    public void channelDown() {
        if (on && channel > 1) {
            channel--;
        }
    }

    // Method untuk menaikkan volume
    public void volumeUp() {
        if (on && volumeLevel < 7) {
            volumeLevel++;
        }
    }

    // Method untuk menurunkan volume
    public void volumeDown() {
        if (on && volumeLevel > 1) {
            volumeLevel--;
        }
    }
}